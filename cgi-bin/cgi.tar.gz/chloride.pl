#!/usr/bin/perl -wT

# A Virtual Lab: Determination of % NaCl by mass
# Patrick E. Fleming
# California State University, East Bay
# June 23, 2020 

# this virtual titration experiment is based on my own ridiculous
# notion that this was a good idea.

use CGI qw(:standard);
use CGI::Carp qw(warningsToBrowser fatalsToBrowser);
# use GD::Graph::lines;
use strict;

# parse the input and set global varialbes
my $flow = param('control_1');		# Determines part
my $i = 0;							# looping variable

my $mmass_cl = 35.45;				# g/mol
my $mmass_nacl = 58.44;				# g/mol
my $mmass_mgcl2 = 95.21;			# g/mol
my $mmass_agcl = 143.32;			# g/mol

# Begin html output
print header;
print start_html("An Unknown Chloride");
print "<h1>An Unknown Chloride</h1>\n";

if ($flow eq 'simple') {
	my $unk_pct = sprintf("%.2f", random_value(80, 20));
	my $unk_mass = sprintf("%.4f", random_value(1.2, 0.8));
	
	my $mol_cl = ($unk_pct / 100) * $unk_mass / $mmass_nacl + (1 - $unk_pct / 100) * $unk_mass / $mmass_mgcl2 * 2;
	my $mass_agcl = sprintf("%.4f", $mol_cl * $mmass_agcl);
	my $mass_cl = $mol_cl * $mmass_cl;
	my $pct_cl = $mass_cl / $unk_mass * 100;
	my $mol_nacl = ($unk_mass * $unk_pct / 100) / $mmass_nacl;
	my $mass_nacl = $unk_mass * $unk_pct / 100;
	my $pct_nacl = $mass_nacl / $unk_mass * 100;

	print <<EOF;
	<h2>Practice</h2>
	<form action="/~pfleming/cgi-bin/chloride.pl" method="post">
	<table border="2" cellpadd="2">
		<tr>
			<td bgcolor="ccffcc" colspan="2"><font size="+1"><b>Data</b></font></td>
		</tr>
		<tr>
			<td bgcolor="ffffcc">Chlorine</td> 
			<td bgcolor="ffffcc">35.45 g/mol</td>
		</tr>
		<tr>
			<td bgcolor="ffffcc">NaCl</td> 
			<td bgcolor="ffffcc">58.44 g/mol</td>
		</tr>
		<tr>
			<td bgcolor="ffffcc">MgCl<sub>2</sub></td> 
			<td bgcolor="ffffcc">95.21 g/mol</td>
		</tr>
		<tr>
			<td bgcolor="ffffcc">AgCl</td> 
			<td bgcolor="ffffcc">143.32 g/mol</td>
		</tr>
		<tr>
			<td>Mass of sample of unknown</td> <td>$unk_mass g</td>
		</tr>
		<tr>
			<td>Mass of AgCl recovered</td> <td>$mass_agcl g</td>
		</tr>
		<tr>
			<td>Moles of Cl<sup>-</sup></td>
			<td><input name="mol_cl_ans"> mol</td>
		</tr>
		<tr>
			<td>Mass of Cl<sup>-</sup></td>
			<td><input name="mass_cl_ans"> g</td>
		</tr>
		<tr>
			<td>% by mass Cl<sup>-</sup> in unknown</td>
			<td><input name="pct_cl_ans"> %</td>
		</tr>
		<tr>
			<td>Moles of NaCl in sample</td>
			<td><input name="mol_nacl_ans"> mol</td>
		</tr>
		<tr>
			<td>Mass NaCl in sample</td>
			<td><input name="mass_nacl_ans"> g</td>
		</tr>
		<tr>
			<td>% by mass NaCl in unknown</td>
			<td><input name="pct_nacl_ans"> %</td>
		</tr>
		<tr>
			<td><input type="submit" value="Am I right?"></td>
			<td><input type="reset" value="Start over"></td>
		</tr>
	</table>
	<input type="hidden" name="mol_cl"    value="$mol_cl">
	<input type="hidden" name="mass_cl"   value="$mass_cl">
	<input type="hidden" name="pct_cl"    value="$pct_cl">
	<input type="hidden" name="unk_mass"  value="$unk_mass">
	<input type="hidden" name="mass_agcl" value="$mass_agcl">
	<input type="hidden" name="mol_nacl"  value="$mol_nacl">
	<input type="hidden" name="mass_nacl" value="$mass_nacl">
	<input type="hidden" name="pct_nacl"  value="$pct_nacl">
	<input type="hidden" name="control_1" value="grade_simple">
	</form><br>
EOF

} elsif ($flow eq 'grade_simple') {
	# read parameters
	my $mol_cl = param('mol_cl');
	my $mass_cl = param('mass_cl');
	my $pct_cl = param('pct_cl');
	my $mol_cl_ans = param('mol_cl_ans');
	my $mass_cl_ans = param('mass_cl_ans');
	my $pct_cl_ans = param('pct_cl_ans');
	my $mol_nacl_ans = param('mol_nacl_ans');
	my $mass_nacl_ans = param('mass_nacl_ans');
	my $pct_nacl_ans = param('pct_nacl_ans');
	my $unk_mass = param('unk_mass');
	my $mass_agcl = param('mass_agcl');
	my $mol_nacl = param('mol_nacl');
	my $mass_nacl = param('mass_nacl');
	my $pct_nacl = param('pct_nacl');
	
	# Grade answers
	my $response_1 = "<font color=\"red\">You are incorrect.</font>";
	my $response_2 = "<font color=\"red\">You are incorrect.</font>";
	my $response_3 = "<font color=\"red\">You are incorrect.</font>";
	my $response_4 = "<font color=\"red\">You are incorrect.</font>";
	my $response_5 = "<font color=\"red\">You are incorrect.</font>";
	my $response_6 = "<font color=\"red\">You are incorrect.</font>";
	if (abs($mol_cl - $mol_cl_ans)/$mol_cl < 0.0002) {
		$response_1 = "<font color=\"green\">You are correct!</font>";
	}
	if (abs($mass_cl - $mass_cl_ans)/$mass_cl < 0.0002) {
		$response_2 = "<font color=\"green\">You are correct!</font>";
	}
	if (abs($pct_cl - $pct_cl_ans)/$pct_cl < 0.0002) {
		$response_3 = "<font color=\"green\">You are correct!</font>";
	}
	if (abs($mol_nacl - $mol_nacl_ans)/$mol_nacl < 0.002) {
		$response_4 = "<font color=\"green\">You are correct!</font>";
	}
	if (abs($mass_nacl - $mass_nacl_ans)/$mass_nacl < 0.002) {
		$response_5 = "<font color=\"green\">You are correct!</font>";
	}
	if (abs($pct_nacl - $pct_nacl_ans)/$pct_nacl < 0.002) {
		$response_6 = "<font color=\"green\">You are correct!</font>";
	}
	print <<EOF;
	<table border="3" cellpadd="2">
		<tr>
			<td bgcolor="ffcccc" colspan="3"><font size="+1"><b>Data</b></font></td>
		</tr>
		<tr>
			<td>Mass of sample of unknown</td> <td>$unk_mass g</td> <td bgcolor="cccccc"></td>
		</tr>
		<tr>
			<td>Mass of AgCl recovered</td> <td>$mass_agcl g</td> <td bgcolor="cccccc"></td>
		</tr>
		<tr>
			<td>Moles of Cl<sup>-</sup></td>
			<td>$mol_cl_ans mol</td>
			<td>$response_1</td>
		</tr>
		<tr>
			<td>Mass of Cl<sup>-</sup></td>
			<td>$mass_cl_ans g</td>
			<td>$response_2</td>
		</tr>
		<tr>
			<td>% by mass Cl<sup>-</sup> in unknown</td>
			<td>$pct_cl_ans %</td>
			<td>$response_3</td>
		</tr>
		<tr>
			<td>Moles of NaCl in sample</td>
			<td>$mol_nacl_ans mol</td>
			<td>$response_4</td>
		</tr>
		<tr>
			<td>Mass of NaCl in sample</td>
			<td>$mass_nacl_ans g</td>
			<td>$response_5</td>
		</tr>
		<tr>
			<td>% by mass NaCl in unknown</td>
			<td>$pct_nacl_ans %</td>
			<td>$response_6</td>
		</tr>
	</table>
EOF

} elsif ($flow eq 'full') {
	print "This option is not yet available.\n";

} else {
	print "No Part Specified!<br>\n";

}

# Finish html output
print "	<footer>\n";
print "		<hr>\n";
print "		<p><b>This work is made available under the <a href=\"https://creativecommons.org/licenses/by-nc/4.0/\">Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)</a> license.</b></p>\n";
print "		Patrick E. Fleming<br>\n";
print "		Department of Chemistry and Biochemistry<br>\n";
print "		California State University, East Bay<br>\n";
print "		<a href=\"mailto:patrick.fleming\@csueastbay.edu\">patrick.fleming\@csueastbay.edu</a>\n";
print "	</footer>\n";

print end_html;

sub random_value {
	my $max = $_[0];
	my $min = $_[1];
	my $value = rand(1) * ($max - $min) + $min;
	return $value;
}

